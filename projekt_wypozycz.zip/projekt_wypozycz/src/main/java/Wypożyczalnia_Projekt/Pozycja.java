package Wypożyczalnia_Projekt;

import java.util.Date;
import java.util.UUID;

public class Pozycja {

          //Dane dotyczace kazdej pozycji w systemie
          String tytul;
          String autor;
          Date datawydania;
          UUID numerpozycji;
          int cena;
          boolean statusdostepny;

          //Tworzenie elementow w klasie
          public Pozycja(String tytul, String autor, Date datawydania, int cena){

              this.tytul = tytul;
              this.autor = autor;
              this.datawydania = datawydania;
              this.numerpozycji = numerpozycji;
              this.cena = cena;
          }

          public void wypozyczenie()
          {
              if(this.statusdostepny)
              {
                  java.lang.System.out.println("Pozycja gotowa do wypozyczenia" + this.tytul);
              }
              else
              {
                  this.statusdostepny = false;
                  this.datawydania = new Date();
              }
          }

          public void oddanie()
          {
              if (this.statusdostepny)
              {
                  this.statusdostepny = true;
              }
              else
              {
                  java.lang.System.out.println("Ksiazka zostala oddana" + this.tytul);
              }
          }

    public String gTYTUL(){
        return this.tytul;
    }

}



