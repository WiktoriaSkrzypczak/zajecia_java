package Wypożyczalnia_Projekt;

//Import wykorzystanych opcji
import javax.print.DocFlavor;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

//Publiczna klasa panelu klienta
public class Panel_Klienta {
    String imie;
    String nazwisko;
    String adres;
    int wiek;
    boolean pelnoletnosc;
    Date zapis_do_biblioteki;
    UUID ID;
    List<String> lista_ksiazek = new ArrayList<>();
}

