package Wypożyczalnia_Projekt;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class System_Wypożyczenia {
    ArrayList<Pozycja> lista_pozycji;
    ArrayList<Lista_Klientów> lista_klientow;

    public System_Wypożyczenia() {
        this.lista_pozycji = new ArrayList<>();
        this.lista_klientow = new ArrayList<>();
    }

    public void add(Pozycja X) {
        lista_pozycji.add(X);
    }

    public void add(Lista_Klientów X) {
        lista_klientow.add(X);
    }

    public void zaplata(long data_wypozycz, long data_zwrot) {
        long ilosc_dni = data_zwrot - data_wypozycz;
        //maksymalny czas wypozyczenia 7 dni
        if (ilosc_dni > 7) {
            long liczenie_dni = (ilosc_dni - 7);
            long kara = 2 * liczenie_dni;
            java.lang.System.out.println("Przekroczono limit, do zaplaty jest " + kara + "zlotych");
        } else {
            if (ilosc_dni == 7) {
                java.lang.System.out.println("Musisz dzisiaj oddac wypozyczona pozycje");
            } else {
                long ile_dni_zostalo = 7 - ilosc_dni;
                java.lang.System.out.println("Zostalo ci " + ile_dni_zostalo + " na oddanie pozycji");
            }
        }
    }

    public void showSystem_Wypozyczenia() {
        for (Pozycja x : this.lista_pozycji) {
            java.lang.System.out.println(x.tytul);

        }
    }


}



