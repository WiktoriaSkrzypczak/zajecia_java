package Wypożyczalnia_Projekt;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

//Klasa z ilością klientów w wypożyczalni, na potrzeby projektu stworzono jednego klienta
public class Lista_Klientów {
    public Panel_Klienta pierwszy_klient;

    public  Lista_Klientów(String imie, String nazwisko, String adres, int wiek, boolean pelnoletnosc, Date zapis_do_bilioteki, UUID numerklienta)
    {
        this.pierwszy_klient = new Panel_Klienta();
        pierwszy_klient.imie = imie;
        pierwszy_klient.nazwisko= nazwisko;
        pierwszy_klient.adres= adres;
        pierwszy_klient.wiek = wiek;
        pierwszy_klient.pelnoletnosc = true;
        pierwszy_klient.zapis_do_biblioteki = zapis_do_bilioteki;
        pierwszy_klient.ID = UUID.randomUUID();
        pierwszy_klient.lista_ksiazek = new ArrayList<>();


    }

    public void wyp(String x)
    {
        pierwszy_klient.lista_ksiazek.add(x);
    }

    public void zwrot(String x)
    {
        pierwszy_klient.lista_ksiazek.remove(x);
    }

    public UUID getID()
    {
        return pierwszy_klient.ID;
    }

    public void show()
    {
        java.lang.System.out.println(pierwszy_klient.lista_ksiazek);
    }
}

